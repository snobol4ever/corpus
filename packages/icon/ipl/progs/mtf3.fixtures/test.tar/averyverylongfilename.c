#include "anotherlongername.icn"
int main() { return 0; }
